package main;

import javafx.scene.Scene;
import javafx.stage.Stage;

public class Global {
    public static Stage WINDOWN;

    public static Scene SCENE_LOGIN;
    public static Scene SCENE_HOME;
}
